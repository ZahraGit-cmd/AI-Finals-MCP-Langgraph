# server.py
import asyncio
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

# Before
# from mcp.server.fastmcp import FastMCP

# After
from fastmcp import FastMCP
from fastmcp.resources import types as mcp_types
from fastmcp.tools import Tool


# from fastmcp import server, too, types as mcp_types

# Create the MCP server
server = FastMCP(name="python-exec-sse", version="0.1.0")

# Utility: execute Python code in a subprocess with timeout and no imports by default
async def execute_python(code: str, timeout: float = 2.0) -> dict:
    # Write to a temp file to avoid passing via argv
    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = Path(tmpdir) / "snippet.py"

        # Optional: basic guardrails — you can expand this list
        blocked = ["import os", "import sys", "subprocess", "__import__", "open(", "socket", "requests"]
        lowered = code.lower()
        if any(b in lowered for b in blocked):
            return {
                "ok": False,
                "stderr": "Blocked code patterns detected. Imports and I/O are restricted.",
                "stdout": "",
                "returncode": None,
            }

        script_path.write_text(code, encoding="utf-8")

        # Run in isolated subprocess
        proc = await asyncio.create_subprocess_exec(
            sys.executable, str(script_path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return {
                "ok": proc.returncode == 0,
                "stdout": stdout.decode(),
                "stderr": stderr.decode(),
                "returncode": proc.returncode,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {
                "ok": False,
                "stdout": "",
                "stderr": f"Execution timed out after {timeout} seconds.",
                "returncode": None,
            }

# Define the MCP tool

@server.tool(
    name="run_python_tool",
    description="Execute a Python snippet",

)
async def run_python_tool(code: str) :
    timeout: float = 5.0
    result = await execute_python(code, timeout=timeout)

    # Return as MCP ToolResult with structured content
    return result

@server.tool(
    name="greet",
    description="Greet a user by name",
)
async def greet(name: str):
    return f"Hi {name}"


if __name__ == "__main__":
    # SSE transport; defaults shown — customize host/port as needed
    # Clients connect via HTTP and receive Server-Sent Events streams.
    server.run(transport="sse", port=8000)
    # server.run(transport="http")




