CREATE TABLE Roles (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(20) CHECK (role IN ('Employee', 'HR', 'Finance', 'Admin')),
    password_hash VARCHAR(255) DEFAULT ''
);

INSERT INTO Roles (emp_id, first_name, last_name, role, password_hash) VALUES
(101, 'Alice', 'Johnson', 'HR', '508365f1283f62d0b8f9cec478f3360e8ff0774f6f6f878feb5f3a4651583eca'),
(102, 'Bob', 'Smith', 'Employee', '37873ee73b109d93cb2a9974f856420b454e342bd4da4ad6c6f3c8faa8ee3efd'),
(103, 'Carol', 'Lee', 'Finance', '8cec04b7bca02cb7944f9ab87ed4c1f65d78af18020f0755d35f53efe4762c76'),
(104, 'David', 'Brown', 'Employee', '06d316f53af69f1d532fc0819b570f40fcba3f668656ab0cb75a05841aa966ba'),
(105, 'Eve', 'Taylor', 'HR', '559ffe7a16c3fb7405e06580411eac622c2204deb9d8fdbb5595654061712373'),
(106, 'Frank', 'Miller', 'Finance', '27f9e9519bee94e1b6478f93171e89ea8b26b56b1056cf6c00a04ff535ffd238'),
(107, 'Grace', 'Wilson', 'Employee', '39d8d7c08552096d33f42c106024e3c6088522a9909961ede17ac18bfede7ae9'),
(108, 'Henry', 'Davis', 'Finance', '08632d4d096412b08f86e7242d1db69acaa283493395e4cdcdee77bc0843af97'),
(109, 'Ivy', 'Moore', 'Employee', '22be515e02f5b9af6b0efeeaa76e8d02039b4e68b539988d8b3d02707354c9ff'),
(110, 'Jack', 'White', 'HR', '12e99b5c67d25c724857f4027f9b54d7ade6e3ea2d9f38d9b72fa01c2da51c0c'),
(111, 'Sam', 'Carter', 'Admin', '9af84b9ea752b5f82b9bcf5675bc23c99794eddd8c1707e7842f8ef654265394'),
(112, 'Alex', 'Rivera', 'Admin', '747faf29446480d8c58f3183ea10351359359444920b2f2b93cada39068b40f4');