
from langchain_core.tools.structured import StructuredTool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
# from langchain_google_genai.chat_models import ChatGoogleGenerativeAI
from fastmcp import Client
from pydantic import BaseModel, Field, create_model
import asyncio
from typing import Any, Dict
# from langgraph.prebuilt import create_react_agent
from dotenv import load_dotenv

load_dotenv()

client = Client("http://127.0.0.1:8000/sse")


def create_langchain_tools_from_mcp():
    """Dynamically creates LangChain tools from MCP server tools"""
    
    async def _discover_tools():
        async with client:
            tools_list = await client.list_tools()
            return tools_list
    
    mcp_tools = asyncio.run(_discover_tools())
    langchain_tools = []
    
    for tool_info in mcp_tools:
        tool_name = tool_info.name
        tool_description = tool_info.description or f"Tool: {tool_name}"
        
        # Extract input schema from tool_info
        input_schema = tool_info.inputSchema
        properties = input_schema.get("properties", {})
        required = input_schema.get("required", [])
        
        # Dynamically create Pydantic model for tool arguments
        field_definitions = {}
        for param_name, param_info in properties.items():
            param_type = param_info.get("type", "string")
            param_desc = param_info.get("description", "")
            
            # Map JSON schema types to Python types
            type_mapping = {
                "string": str,
                "integer": int,
                "number": float,
                "boolean": bool,
                "object": Dict,
                "array": list
            }
            
            python_type = type_mapping.get(param_type, str)
            is_required = param_name in required
            
            if is_required:
                field_definitions[param_name] = (
                    python_type, 
                    Field(..., description=param_desc)
                )
            else:
                field_definitions[param_name] = (
                    python_type, 
                    Field(None, description=param_desc)
                )
        
        # Create the Pydantic model dynamically
        ArgsModel = create_model(
            f"{tool_name}_args",
            **field_definitions
        )
        
        # Create the wrapper function
        def create_tool_func(name: str):
            async def _call_tool(**kwargs):
                async with client:
                    result = await client.call_tool(name, kwargs)
                    
                    # Handle different response formats
                    if hasattr(result, 'data') and isinstance(result.data, dict):
                        # Return structured data (e.g., stdout)
                        return result.data.get("stdout", str(result.data))
                    elif hasattr(result, 'content') and result.content:
                        # Return text content
                        return result.content[0].text
                    else:
                        return str(result)
            
            def sync_wrapper(**kwargs):
                return asyncio.run(_call_tool(**kwargs))
            
            return sync_wrapper
        
        # Create StructuredTool
        langchain_tool = StructuredTool(
            name=tool_name,
            description=tool_description,
            func=create_tool_func(tool_name),
            args_schema=ArgsModel,
            return_direct=True
        )
        
        langchain_tools.append(langchain_tool)
    
    return langchain_tools

import httpx 

client_httpx = httpx.Client(verify=False)
def get_llm():
    return ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-QibkR-xrOxD2AsMgdaL0Pg", # type: ignore
    http_client=client_httpx
)


def main():
    # Get LLM
    llm = get_llm()
    
    # Dynamically load tools from MCP server
    tools = create_langchain_tools_from_mcp()
    
    print(f"Loaded {len(tools)} tools from MCP server:")
    for tool in tools:
        print(f"  - {tool.name}: {tool.description}")
    print()
    
    # Create agent with dynamically loaded tools
    graph = create_agent(
        model=llm,
        tools=tools,
        system_prompt="You are a helpful assistant with access to various tools.",
    )
    
    # Test the agent
    inputs = {"messages": [{"role": "user", "content": "execute hello world"}]}
    
    import json
    
    for chunk in graph.stream(inputs, stream_mode="updates"):
        # If it's a tool message
        if "tools" in chunk and "messages" in chunk["tools"]:
            for msg in chunk["tools"]["messages"]:
                data = msg.content
                print(">>> Tool Output:")
                print(data)
        # If it's a model message
        elif "model" in chunk and "messages" in chunk["model"]:
            for msg in chunk["model"]["messages"]:
                if msg.content:
                    print(f"[{msg.__class__.__name__}] {msg.content}")
                elif msg.additional_kwargs.get("function_call"):
                    fn = msg.additional_kwargs["function_call"]
                    print(f"→ Calling tool: {fn['name']} with {fn['arguments']}")
        else:
            # fallback: pretty JSON
            print(json.dumps(chunk, indent=2, default=str))


if __name__ == "__main__":
    main()