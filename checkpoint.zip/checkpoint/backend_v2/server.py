import uvicorn
from fastapi import FastAPI, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import os
from fastapi.middleware.cors import CORSMiddleware
import sqlite3
import hashlib
from datetime import datetime, timedelta
import secrets
import json
from langgraph.checkpoint.sqlite import SqliteSaver

# Assuming these imports exist in your project
from agent import create_database_workflow, MultiServerMCPClient

# -------------------------------------------------------
#                   SESSION MANAGEMENT
# -------------------------------------------------------
sessions = {}  # In-memory session storage

def create_session(emp_id: int, role: str, first_name: str, last_name: str) -> str:
    session_id = secrets.token_urlsafe(32)
    sessions[session_id] = {
        "emp_id": emp_id,
        "role": role,
        "first_name": first_name,
        "last_name": last_name,
        "expires_at": datetime.now() + timedelta(hours=24)
    }
    return session_id

def validate_session(session_id: str) -> Optional[Dict]:
    if session_id not in sessions:
        return None
    session = sessions[session_id]
    if datetime.now() > session["expires_at"]:
        del sessions[session_id]
        return None
    return session

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# -------------------------------------------------------
#                   DATABASE HELPERS
# -------------------------------------------------------
DB_PATH = "./employee_details_1000.db"
CHECKPOINT_DB = "./checkpoints.db"
USERS_DB_PATH = "./user_access.db"

def get_db_connection():
    conn = sqlite3.connect(USERS_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def verify_user(emp_id: int, password: str) -> Optional[Dict]:
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT emp_id, first_name, last_name, role, password_hash FROM Roles WHERE emp_id = ?",
            (emp_id,)
        )
        user = cursor.fetchone()
        conn.close()
        
        if not user:
            return None
        
        password_hash = hash_password(password)
        if user["password_hash"] != password_hash:
            print("wrong password")
            return None
        print("password correct")
        return {
            "emp_id": user["emp_id"],
            "first_name": user["first_name"],
            "last_name": user["last_name"],
            "role": user["role"]
        }
    except Exception as e:
        print(f"Error verifying user: {e}")
        return None

# -------------------------------------------------------
#                   AGENT SETUP
# -------------------------------------------------------
async def get_agent():
    mcp_client = None
    try:
        mcp_client = MultiServerMCPClient({
            "db_server": {
                "url": "http://localhost:8000/sse",
                "transport": "sse"
            }
        })
        tools = await mcp_client.get_tools()
        print(f"MCP Server Connected - {len(tools)} tool(s) available")
    except Exception as e:
        print(f"MCP server not available: {e}")
        return None

    agent = create_database_workflow(mcp_client)
    return agent

# -------------------------------------------------------
#                   FASTAPI APP
# -------------------------------------------------------
app = FastAPI(title="Database Analysis API")

# Templates
templates = Jinja2Templates(directory="templates")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Checkpointer
checkpointer = SqliteSaver.from_conn_string(CHECKPOINT_DB)

# -------------------------------------------------------
#                   PYDANTIC MODELS
# -------------------------------------------------------
class LoginRequest(BaseModel):
    emp_id: int
    password: str

class LoginResponse(BaseModel):
    session_id: str
    emp_id: int
    first_name: str
    last_name: str
    role: str

class ChatRequest(BaseModel):
    message: str
    session_id: str

class ChatResponse(BaseModel):
    reply: str
    sql_query: Optional[str] = None
    reject_reason: str
    next_agent : str
    results: Optional[List[Dict]] = None
    history: Optional[List[str]] = None
    steps: List[Dict] = []
    summary: str
    follow_up_questions: List[str] = []
    visualization_data: Dict[str, Any] = {}
    error : str = ""

# -------------------------------------------------------
#                   WEB ROUTES
# -------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login-form")
async def login_form(request: Request, emp_id: int = Form(...), password: str = Form(...)):
    user = verify_user(emp_id, password)
    print(user)
    if not user:
        return templates.TemplateResponse(
            "login.html", 
            {"request": request, "error": "Invalid credentials"}
        )
    
    session_id = create_session(
        user["emp_id"], 
        user["role"], 
        user["first_name"], 
        user["last_name"]
    )
    
    response = RedirectResponse(url="/chat", status_code=303)
    response.set_cookie(key="session_id", value=session_id, httponly=True)
    return response

@app.get("/chat", response_class=HTMLResponse)
async def chat_page(request: Request):
    session_id = request.cookies.get("session_id")
    
    if not session_id:
        return RedirectResponse(url="/")
    
    session = validate_session(session_id)
    if not session:
        return RedirectResponse(url="/")
    
    return templates.TemplateResponse(
        "chat.html", 
        {
            "request": request,
            "user": session
        }
    )

@app.get("/logout")
async def logout(request: Request):
    session_id = request.cookies.get("session_id")
    if session_id and session_id in sessions:
        del sessions[session_id]
    
    response = RedirectResponse(url="/")
    response.delete_cookie("session_id")
    return response

# -------------------------------------------------------
#                   API ENDPOINTS
# -------------------------------------------------------
@app.post("/api/login", response_model=LoginResponse)
async def api_login(request: LoginRequest):
    user = verify_user(request.emp_id, request.password)
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    session_id = create_session(
        user["emp_id"], 
        user["role"],
        user["first_name"],
        user["last_name"]
    )
    
    return LoginResponse(
        session_id=session_id,
        emp_id=user["emp_id"],
        first_name=user["first_name"],
        last_name=user["last_name"],
        role=user["role"]
    )

@app.post("/api/chat", response_model=ChatResponse)
async def api_chat(request: ChatRequest):
    try:
        session = validate_session(request.session_id)
        if not session:
            raise HTTPException(status_code=401, detail="Invalid or expired session")
        
        if not os.path.exists(DB_PATH):
            raise HTTPException(status_code=404, detail="Database not found.")
        
        emp_id = session["emp_id"]
        role = session["role"]
        
        agent = await get_agent()
        if not agent:
            raise HTTPException(status_code=500, detail="Agent initialization failed")
        
        thread_id = f"user_{emp_id}_{request.session_id}"
        
        initial_state = {
            "db_path": DB_PATH,
            "schema_info": {},
            "user_query": request.message,
            "sql_query": "",
            "query_results": [],
            "visualization_type": "",
            "visualization_data": {},
            "history": [],
            "next_agent": "schema_agent",
            "error": "",
            "query_metadata": {},
            "steps": [],
            "user_role": role,
            "summary": "",
            "reject_reason": "",
            "follow_up_questions": [],
            "user_empid": emp_id,
            "user_role": role
        }
        
        config = {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": "",
            }
        }
        
        final_state = agent.invoke(initial_state, config=config)
        
        formatted_output = ""
        # print(final_state["query_results"])
        # print(final_state["query_results"])
        print("visualization")
        print(final_state.get("visualization_data", {}))

        return ChatResponse(
            reply=formatted_output or "Query completed.",
            sql_query=final_state.get("sql_query"),
            reject_reason=final_state.get("reject_reason", ""),
            next_agent=final_state.get("next_agent", ""),
            results=final_state["query_results"],
            history=final_state.get("history", []),
            steps=final_state.get("steps", []),
            summary=final_state.get("summary", ""),
            follow_up_questions=final_state.get("follow_up_questions", []),
            visualization_data=final_state.get("visualization_data", {})
        )
    
    except HTTPException:
        raise
    except Exception as e:
        print("Error occurred while processing chat request:")
        print(e)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/session")
async def get_session(request: Request):
    session_id = request.cookies.get("session_id")
    
    if not session_id:
        raise HTTPException(status_code=401, detail="No session found")
    
    session = validate_session(session_id)
    if not session:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    return {
        "session_id": session_id,
        "emp_id": session["emp_id"],
        "first_name": session["first_name"],
        "last_name": session["last_name"],
        "role": session["role"]
    }

# -------------------------------------------------------
#                        MAIN
# -------------------------------------------------------
if __name__ == "__main__":
    print("\n🚀 Starting DB Analysis Server...\n")
    print(f"📊 Database: {DB_PATH}")
    print(f"💾 Checkpoint DB: {CHECKPOINT_DB}")
    print("\n🌐 Open http://localhost:5000 to access the application\n")
    uvicorn.run(app, host="0.0.0.0", port=5000)