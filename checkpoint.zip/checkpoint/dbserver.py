"""
Database MCP Server using FastMCP
Provides tools for database operations

Run this server first before running the client:
    python db_mcp_server.py

Then in another terminal:
    python db_agent_client.py
"""

from fastmcp import FastMCP
import sqlite3
import json
from typing import List, Dict, Any

# Initialize FastMCP server
mcp = FastMCP("Database Server")


@mcp.tool()
def execute_query(db_path: str, query: str) -> str:
    """
    Execute a SQL query on the specified database
    
    Args:
        db_path: Path to the SQLite database file
        query: SQL query to execute
    
    Returns:
        JSON string with query results or error
    """
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(query)
        
        # Handle SELECT queries
        if query.strip().upper().startswith('SELECT'):
            rows = cursor.fetchall()
            results = [dict(row) for row in rows]
            
            response = {
                "success": True,
                "query": query,
                "row_count": len(results),
                "results": results
            }
        else:
            # Handle INSERT, UPDATE, DELETE
            conn.commit()
            response = {
                "success": True,
                "query": query,
                "affected_rows": cursor.rowcount
            }
        
        conn.close()
        return json.dumps(response)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
            "query": query
        })


@mcp.tool()
def get_schema(db_path: str) -> str:
    """
    Get database schema information
    
    Args:
        db_path: Path to the SQLite database file
    
    Returns:
        JSON string with schema information
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        schema = {}
        for (table_name,) in tables:
            # Get table info
            cursor.execute(f"PRAGMA table_info({table_name});")
            columns = cursor.fetchall()
            
            schema[table_name] = {
                "columns": [
                    {
                        "id": col[0],
                        "name": col[1],
                        "type": col[2],
                        "not_null": bool(col[3]),
                        "default_value": col[4],
                        "primary_key": bool(col[5])
                    }
                    for col in columns
                ]
            }
            
            # Get row count
            cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
            count = cursor.fetchone()[0]
            schema[table_name]["row_count"] = count
        
        conn.close()
        
        return json.dumps({
            "success": True,
            "schema": schema,
            "table_count": len(schema)
        })
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })


@mcp.tool()
def get_table_preview(db_path: str, table_name: str, limit: int = 5) -> str:
    """
    Get a preview of table data
    
    Args:
        db_path: Path to the SQLite database file
        table_name: Name of the table
        limit: Number of rows to return (default: 5)
    
    Returns:
        JSON string with preview data
    """
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(f"SELECT * FROM {table_name} LIMIT ?", (limit,))
        rows = cursor.fetchall()
        results = [dict(row) for row in rows]
        
        conn.close()
        
        return json.dumps({
            "success": True,
            "table": table_name,
            "preview": results,
            "row_count": len(results)
        })
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e),
            "table": table_name
        })


@mcp.tool()
def aggregate_query(db_path: str, table: str, column: str, operation: str, 
                   group_by: str = None, where_clause: str = None) -> str:
    """
    Perform aggregate operations on database
    
    Args:
        db_path: Path to the SQLite database file
        table: Table name
        column: Column to aggregate
        operation: Aggregate operation (COUNT, SUM, AVG, MIN, MAX)
        group_by: Optional column to group by
        where_clause: Optional WHERE clause (without WHERE keyword)
    
    Returns:
        JSON string with aggregation results
    """
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Build query
        operation = operation.upper()
        if operation not in ['COUNT', 'SUM', 'AVG', 'MIN', 'MAX']:
            raise ValueError(f"Invalid operation: {operation}")
        
        if group_by:
            query = f"SELECT {group_by}, {operation}({column}) as result FROM {table}"
        else:
            query = f"SELECT {operation}({column}) as result FROM {table}"
        
        if where_clause:
            query += f" WHERE {where_clause}"
        
        if group_by:
            query += f" GROUP BY {group_by}"
        
        cursor.execute(query)
        rows = cursor.fetchall()
        results = [dict(row) for row in rows]
        
        conn.close()
        
        return json.dumps({
            "success": True,
            "query": query,
            "operation": operation,
            "results": results
        })
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })


if __name__ == "__main__":
    print("=" * 70)
    print("DATABASE MCP SERVER - FastMCP")
    print("=" * 70)
    print()
    print("🚀 Starting server on http://localhost:8000")
    print("📡 SSE endpoint: http://localhost:8000/sse")
    print()
    print("Available tools:")
    print("  • execute_query - Execute SQL queries")
    print("  • get_schema - Get database schema")
    print("  • get_table_preview - Preview table data")
    print("  • aggregate_query - Perform aggregations")
    print()
    print("=" * 70)
    print()
    
    # Run the server
    mcp.run(transport="sse")